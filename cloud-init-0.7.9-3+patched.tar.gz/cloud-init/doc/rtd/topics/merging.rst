**************************
Merging User-Data Sections
**************************

.. include:: ../../merging.rst
.. vi: textwidth=78
