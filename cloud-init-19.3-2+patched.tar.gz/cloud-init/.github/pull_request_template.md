***This GitHub repo is only a mirror.  Do not submit pull requests
here!***

Thank you for taking the time to write and submit a change to
cloud-init!   Please follow [our hacking
guide](https://cloudinit.readthedocs.io/en/latest/topics/hacking.html)
to submit your change to cloud-init's [Launchpad git
repository](https://code.launchpad.net/cloud-init/), where cloud-init
development happens.
